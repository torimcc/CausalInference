
.. mdinclude:: ..\..\causallib\datasets\README.md

Submodules
----------

.. toctree::

   causallib.datasets.data_loader

Module contents
---------------

.. automodule:: causallib.datasets
   :members:
   :undoc-members:
   :show-inheritance:
