causallib.contrib.hemm.load\_ihdp\_data module
==============================================

.. automodule:: causallib.contrib.hemm.load_ihdp_data
   :members:
   :undoc-members:
   :show-inheritance:
