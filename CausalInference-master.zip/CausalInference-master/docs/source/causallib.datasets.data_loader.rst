causallib.datasets.data\_loader module
======================================

.. automodule:: causallib.datasets.data_loader
   :members:
   :undoc-members:
   :show-inheritance:
