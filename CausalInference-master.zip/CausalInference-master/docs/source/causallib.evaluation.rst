
.. mdinclude:: ..\..\causallib\evaluation\README.md

Submodules
----------

.. toctree::

   causallib.evaluation.evaluator
   causallib.evaluation.outcome_evaluator
   causallib.evaluation.plots
   causallib.evaluation.weight_evaluator

Module contents
---------------

.. automodule:: causallib.evaluation
   :members:
   :undoc-members:
   :show-inheritance:
