causallib.contrib.hemm.hemm\_outcome\_models module
===================================================

.. automodule:: causallib.contrib.hemm.hemm_outcome_models
   :members:
   :undoc-members:
   :show-inheritance:
