causallib.evaluation.outcome\_evaluator module
==============================================

.. automodule:: causallib.evaluation.outcome_evaluator
   :members:
   :undoc-members:
   :show-inheritance:
