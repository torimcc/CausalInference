.. causallib documentation master file, created by
   sphinx-quickstart on Thu Jun  6 11:47:18 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to causallib's documentation!
=====================================
.. mdinclude:: ../../README.md


Examples
========
Comprehensive Jupyter Notebooks examples can be found in the `examples directory on GitHub <https://github.com/IBM/causallib/tree/master/examples>`_.


Documentation
=============
.. toctree::
   :titlesonly:
   :maxdepth: 5
   :glob:

   causallib
	


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
