causallib.tests.test\_matching module
=====================================

.. automodule:: causallib.tests.test_matching
   :members:
   :undoc-members:
   :show-inheritance:
