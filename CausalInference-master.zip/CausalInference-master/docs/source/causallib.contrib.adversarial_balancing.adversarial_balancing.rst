causallib.contrib.adversarial\_balancing.adversarial\_balancing module
======================================================================

.. automodule:: causallib.contrib.adversarial_balancing.adversarial_balancing
   :members:
   :undoc-members:
   :show-inheritance:
