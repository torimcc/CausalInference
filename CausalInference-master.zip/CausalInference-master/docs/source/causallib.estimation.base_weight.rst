causallib.estimation.base\_weight module
========================================

.. automodule:: causallib.estimation.base_weight
   :members:
   :undoc-members:
   :show-inheritance:
