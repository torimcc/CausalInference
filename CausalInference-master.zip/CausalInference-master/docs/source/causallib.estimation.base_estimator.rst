causallib.estimation.base\_estimator module
===========================================

.. automodule:: causallib.estimation.base_estimator
   :members:
   :undoc-members:
   :show-inheritance:
