causallib.contrib.faissknn module
=================================

.. automodule:: causallib.contrib.faissknn
   :members:
   :undoc-members:
   :show-inheritance:
