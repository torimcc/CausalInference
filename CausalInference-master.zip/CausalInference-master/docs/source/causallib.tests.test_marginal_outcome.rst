causallib.tests.test\_marginal\_outcome module
==============================================

.. automodule:: causallib.tests.test_marginal_outcome
   :members:
   :undoc-members:
   :show-inheritance:
