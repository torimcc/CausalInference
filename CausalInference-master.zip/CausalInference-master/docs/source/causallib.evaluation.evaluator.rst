causallib.evaluation.evaluator module
=====================================

.. automodule:: causallib.evaluation.evaluator
   :members:
   :undoc-members:
   :show-inheritance:
