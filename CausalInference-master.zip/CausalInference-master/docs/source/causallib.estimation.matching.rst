causallib.estimation.matching module
====================================

.. automodule:: causallib.estimation.matching
   :members:
   :undoc-members:
   :show-inheritance:
