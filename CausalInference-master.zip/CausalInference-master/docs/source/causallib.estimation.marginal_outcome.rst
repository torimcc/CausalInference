causallib.estimation.marginal\_outcome module
=============================================

.. automodule:: causallib.estimation.marginal_outcome
   :members:
   :undoc-members:
   :show-inheritance:
