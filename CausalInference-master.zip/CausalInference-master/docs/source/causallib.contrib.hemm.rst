
.. mdinclude:: ..\..\causallib\contrib\hemm\README.md

Submodules
----------

.. toctree::

   causallib.contrib.hemm.gen_synthetic_data
   causallib.contrib.hemm.hemm
   causallib.contrib.hemm.hemm_api
   causallib.contrib.hemm.hemm_metrics
   causallib.contrib.hemm.hemm_outcome_models
   causallib.contrib.hemm.hemm_utilities
   causallib.contrib.hemm.load_ihdp_data

Module contents
---------------

.. automodule:: causallib.contrib.hemm
   :members:
   :undoc-members:
   :show-inheritance:
