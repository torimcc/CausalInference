
.. mdinclude:: ..\..\causallib\preprocessing\README.md

Submodules
----------

.. toctree::

   causallib.preprocessing.filters
   causallib.preprocessing.transformers

Module contents
---------------

.. automodule:: causallib.preprocessing
   :members:
   :undoc-members:
   :show-inheritance:
