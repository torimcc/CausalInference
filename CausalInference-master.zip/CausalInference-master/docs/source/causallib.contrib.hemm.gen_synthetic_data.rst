causallib.contrib.hemm.gen\_synthetic\_data module
==================================================

.. automodule:: causallib.contrib.hemm.gen_synthetic_data
   :members:
   :undoc-members:
   :show-inheritance:
