
.. mdinclude:: ..\..\causallib\contrib\README.md

Subpackages
-----------

.. toctree::

   causallib.contrib.adversarial_balancing
   causallib.contrib.hemm
   causallib.contrib.tests

Submodules
----------

.. toctree::

   causallib.contrib.faissknn

Module contents
---------------

.. automodule:: causallib.contrib
   :members:
   :undoc-members:
   :show-inheritance:
